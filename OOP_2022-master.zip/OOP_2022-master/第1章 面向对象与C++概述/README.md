## 山东师范大学《面向对象程序设计》课程



**课程实验上机安排**


* 实验班级：` 2101计本 || 2101计师本|| 2101计工本1||2101计工本2|| 2101物联本`

* 上机时间： 每周五晚19:00-20:35

* 上机地点：  E312机房、E315机房 


### 1. 实验目的

---


* 掌握Git的基本工作原理

* 掌握Git的基本命令: git clone , git add , git commit , git push以及版本回退命令 git reset --hard MD5码

* 能够熟练独立使用Git上传源代码到Gitee或Github 

  

### 2. 实验任务
---

* 注册Gitee账号

* 在Gitee里创建名为"OOP_Homework"的仓库

* 在仓库里添加文件夹"第一章 实验任务", "第二章 实验任务"

* 在上述各实验任务文件夹内添加对应章节中任意一个完整的C++源程序

* 提交本地源代码到远程仓库内,检查仓库内容与本地内容是否一致



### 3. Git使用简介
---


1. **第一步**: 注册gitee(建议校园邮箱:xxx@stu.sdnu.edu.cn)

2. **第二步**: 下载安装git([git软件](https://git-scm.com/downloads)), 右键打开git bash here, 控制台窗口配置git用户信息,具体如下两步(只配置1次, 之后无须再配置)

   >   2.1 git config --global user.name  "你的名字"

   >   2.2 git config --global user.email  "你的gitee注册邮箱"

3. **第三步**: gitee里建立仓库(gitee网站里操作,)

4. **第四步**: 克隆该仓库,对仓库源代码进行修改,然后将修改后版本通过git命令上传到gitee远程仓库. 具体过程如下:

   > 克隆框架(git clone 仓库地址)-->添加打包(git add . )-->贴标签(git commit -m "修改bug")-->提交到gitee仓库(git push)
   
![img](gitCommand.png)
