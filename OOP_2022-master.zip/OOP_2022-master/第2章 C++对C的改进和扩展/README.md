## 第二章 C++对C的改进和扩展实验



* 实验班级：` 2101计本 || 2101计师本|| 2101计工本1||2101计工本2|| 2101物联本`

* 上机时间： 每周五晚19:00-20:35

* 上机地点：  E312机房、E315机房 

---

### 一、实验目录


* 第1次实验：[基本程序控制实验](https://gitee.com/tsingke/OOP_CS2021/blob/master/%E7%AC%AC2%E7%AB%A0%20C++%E5%AF%B9C%E7%9A%84%E6%94%B9%E8%BF%9B%E5%92%8C%E6%89%A9%E5%B1%95/%E5%AE%9E%E9%AA%8C%E4%B8%80%EF%BC%9A%E5%9F%BA%E6%9C%AC%E7%A8%8B%E5%BA%8F%E6%8E%A7%E5%88%B6%E5%AE%9E%E9%AA%8C.md)


* 第2次实验：[函数专题综合实验](https://gitee.com/tsingke/OOP_CS2021/blob/master/%E7%AC%AC2%E7%AB%A0%20C++%E5%AF%B9C%E7%9A%84%E6%94%B9%E8%BF%9B%E5%92%8C%E6%89%A9%E5%B1%95/%E5%AE%9E%E9%AA%8C%E4%BA%8C%EF%BC%9AC++%E5%87%BD%E6%95%B0%E4%B8%93%E9%A2%98%E5%AE%9E%E9%AA%8C.md)

* 第3次实验：[指针引用综合实验](https://gitee.com/tsingke/OOP_CS2021/blob/master/%E7%AC%AC2%E7%AB%A0%20C++%E5%AF%B9C%E7%9A%84%E6%94%B9%E8%BF%9B%E5%92%8C%E6%89%A9%E5%B1%95/%E5%AE%9E%E9%AA%8C%E4%B8%89%EF%BC%9A%E5%BC%95%E7%94%A8%E5%92%8C%E5%8A%A8%E6%80%81%E5%86%85%E5%AD%98%E7%94%B3%E8%AF%B7%E5%AE%9E%E9%AA%8C.md)



### 二、 实验说明

---

请务必按照`课程实验报告模板`([点击下载](https://gitee.com/tsingke/OOP_CS2021/raw/master/%E7%AC%AC2%E7%AB%A0%20C++%E5%AF%B9C%E7%9A%84%E6%94%B9%E8%BF%9B%E5%92%8C%E6%89%A9%E5%B1%95/%E9%9D%A2%E5%90%91%E5%AF%B9%E8%B1%A1%E7%A8%8B%E5%BA%8F%E8%AE%BE%E8%AE%A1%E5%AE%9E%E9%AA%8C%E6%8A%A5%E5%91%8A%E6%A8%A1%E6%9D%BF.docx))撰写实验报告，报告内如涉及流程图或矢量图绘制，建议采用微软的[visio](https://pan.baidu.com/s/1L4y1pWXcJjojZlIAQZjPAg)绘制，报告内若需粘贴程序源代码，请采用开源软件 [highlight](http://www.andre-simon.de/zip/highlight-setup-3.53-x64.exe) 将源码转换后粘贴到报告内.  统一提交报告```PDF版本```到云班课。


### 三、附录内容

  **VS调试快捷键**

   ```  
   
   * 单步调试(走马观花F10, 步步深入F11, 配合使用)        : 逐行定位BUG
   
   * 设置断点(F9), 直接运行到光标所在代码行(ctrl + F10) : 部分代码调试
   
   * 注释(ctrl+ K + C), 取消注释(ctrl+ K + U)         : 优雅的写代码
   
   * 代码格式化(先选中代码，然后ctrl + K + F)           : 写优雅的代码
   
   * 定义跳转(F12), 跳回原位(ctrl + 减号)              : 查看源码好帮手
   
   * 一键编译调试运行(F5)                              : 简单粗暴又高效                      
   
   ```